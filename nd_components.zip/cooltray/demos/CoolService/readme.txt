CoolService demo
----------------

Use CoolTrayService.bat to register and start the service.
You need to change the path of SERVICEPATH to this folder.

